
#define NETSNMP_DONT_USE_NLIST 1

#undef bsdlike
